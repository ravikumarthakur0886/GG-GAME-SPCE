package com.gg.gamespace

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class SmartTouchAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return super.onKeyEvent(event)
        val prefs = getSharedPreferences("gg_smart_touch", Context.MODE_PRIVATE)
        return when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                val delay = prefs.getLong("vol_up_delay", 25L)
                val x = prefs.getFloat("vol_up_x", 850f)
                val y = prefs.getFloat("vol_up_y", 1400f)
                triggerSmartTap(x, y, delay)
                true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                val delay = prefs.getLong("vol_down_delay", 35L)
                val x = prefs.getFloat("vol_down_x", 300f)
                val y = prefs.getFloat("vol_down_y", 1500f)
                triggerSmartTap(x, y, delay)
                true
            }
            else -> super.onKeyEvent(event)
        }
    }

    private fun triggerSmartTap(x: Float, y: Float, delayMs: Long) {
        handler.postDelayed({
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0L, 45L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGesture(gesture, null, null)
        }, delayMs)
    }
}
