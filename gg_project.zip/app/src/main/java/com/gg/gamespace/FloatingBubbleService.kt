package com.gg.gamespace

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout

class FloatingBubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_bubble, null)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 140
        }

        val ivIcon = overlayView.findViewById<ImageView>(R.id.ivBubbleIcon)
        val llMenu = overlayView.findViewById<LinearLayout>(R.id.llQuickMenu)
        val llGames = overlayView.findViewById<LinearLayout>(R.id.llOverlayGames)

        ivIcon.setOnClickListener {
            if (llMenu.visibility == View.VISIBLE) {
                llMenu.visibility = View.GONE
            } else {
                populateQuickGames(llGames)
                llMenu.visibility = View.VISIBLE
            }
        }

        var initX = 0
        var initY = 0
        var touchX = 0f
        var touchY = 0f
        ivIcon.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = params.x; initY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initX - (event.rawX - touchX).toInt()
                    params.y = initY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(overlayView, params)
                    true
                }
                else -> false
            }
        }

        windowManager.addView(overlayView, params)
    }

    private fun populateQuickGames(container: LinearLayout) {
        container.removeAllViews()
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val games = apps.filter { app ->
            val isGameCat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && app.category == ApplicationInfo.CATEGORY_GAME
            @Suppress("DEPRECATION")
            val isGameFlag = (app.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            (isGameCat || isGameFlag) && pm.getLaunchIntentForPackage(app.packageName) != null
        }.take(6)

        for (g in games) {
            val btn = Button(this).apply {
                text = pm.getApplicationLabel(g).toString()
                textSize = 11f
                setBackgroundColor(0xFF1D4ED8.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                setOnClickListener {
                    pm.getLaunchIntentForPackage(g.packageName)?.let {
                        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(it)
                    }
                }
            }
            container.addView(btn)
        }
    }

    private fun startForegroundNotification() {
        val chId = "gg_overlay_ch"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(chId, "GG Floating Icon", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val notif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, chId).setContentTitle("GG Game Space Active").setSmallIcon(R.mipmap.ic_launcher).build()
        else
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("GG Game Space Active").setSmallIcon(R.mipmap.ic_launcher).build()
        startForeground(101, notif)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::overlayView.isInitialized) windowManager.removeView(overlayView)
    }
}
