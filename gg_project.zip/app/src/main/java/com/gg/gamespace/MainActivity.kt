package com.gg.gamespace

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences("gg_smart_touch", Context.MODE_PRIVATE)
        val etVolUpDelay = findViewById<EditText>(R.id.etVolUpDelay)
        val etVolUpX = findViewById<EditText>(R.id.etVolUpX)
        val etVolUpY = findViewById<EditText>(R.id.etVolUpY)
        val etVolDownDelay = findViewById<EditText>(R.id.etVolDownDelay)
        val etVolDownX = findViewById<EditText>(R.id.etVolDownX)
        val etVolDownY = findViewById<EditText>(R.id.etVolDownY)

        etVolUpDelay.setText(prefs.getLong("vol_up_delay", 25L).toString())
        etVolUpX.setText(prefs.getFloat("vol_up_x", 850f).toInt().toString())
        etVolUpY.setText(prefs.getFloat("vol_up_y", 1400f).toInt().toString())
        etVolDownDelay.setText(prefs.getLong("vol_down_delay", 35L).toString())
        etVolDownX.setText(prefs.getFloat("vol_down_x", 300f).toInt().toString())
        etVolDownY.setText(prefs.getFloat("vol_down_y", 1500f).toInt().toString())

        findViewById<Button>(R.id.btnOverlayPerm).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivity(intent)
            } else {
                Toast.makeText(this, "Overlay permission already granted!", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnAccPerm).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnStartBubble).setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                val svc = Intent(this, FloatingBubbleService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc) else startService(svc)
            } else {
                Toast.makeText(this, "Grant Overlay Permission first!", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnSaveSmartTouch).setOnClickListener {
            prefs.edit()
                .putLong("vol_up_delay", etVolUpDelay.text.toString().toLongOrNull() ?: 25L)
                .putFloat("vol_up_x", etVolUpX.text.toString().toFloatOrNull() ?: 850f)
                .putFloat("vol_up_y", etVolUpY.text.toString().toFloatOrNull() ?: 1400f)
                .putLong("vol_down_delay", etVolDownDelay.text.toString().toLongOrNull() ?: 35L)
                .putFloat("vol_down_x", etVolDownX.text.toString().toFloatOrNull() ?: 300f)
                .putFloat("vol_down_y", etVolDownY.text.toString().toFloatOrNull() ?: 1500f)
                .apply()
            Toast.makeText(this, "Smart-Touch ms timing saved!", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnScanGames).setOnClickListener {
            scanInstalledGames()
        }
        scanInstalledGames()
    }

    private fun scanInstalledGames() {
        val container = findViewById<LinearLayout>(R.id.gamesContainer)
        container.removeAllViews()
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val games = apps.filter { app ->
            val isGameCategory = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && app.category == ApplicationInfo.CATEGORY_GAME
            @Suppress("DEPRECATION")
            val isGameFlag = (app.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            (isGameCategory || isGameFlag) && pm.getLaunchIntentForPackage(app.packageName) != null
        }

        if (games.isEmpty()) {
            val btn = Button(this).apply {
                text = "No games flagged by OS — Tap to re-scan"
                setOnClickListener { scanInstalledGames() }
            }
            container.addView(btn)
            return
        }

        for (game in games) {
            val label = pm.getApplicationLabel(game).toString()
            val btn = Button(this).apply {
                text = "Launch: $label"
                setBackgroundColor(0xFF0E1A38.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                setOnClickListener {
                    pm.getLaunchIntentForPackage(game.packageName)?.let { startActivity(it) }
                }
            }
            container.addView(btn)
        }
    }
}
